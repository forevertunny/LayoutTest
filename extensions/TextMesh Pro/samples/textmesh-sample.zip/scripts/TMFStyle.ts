import { _decorator, Component} from 'cc';
import { StyleManager } from 'db://text-mesh/index';

const { ccclass, property,executeInEditMode,executionOrder } = _decorator;
 
@ccclass('TMFStyle')
@executeInEditMode
@executionOrder(-1)
export class TMFStyle extends Component {
    @property({serializable: true})
    private _style = "";

    @property({multiline: true})
    get style() {
        return this._style;
    }

    set style(value) {
        if(this._style === value) {
            return;
        }
        this._style = value;

        StyleManager.registByJson(this._style);
    }

    onLoad() {
        StyleManager.registByJson(this._style);
    }
}