
import { _decorator, Component, Node, Canvas, Event, Color, math, UIOpacity, Sprite, SpriteFrame, setDisplayStats, profiler } from 'cc';
import { TextMeshLabel, EventClickChar, Utils, CharInfo } from 'db://text-mesh/index';
import { TextMeshSettings } from 'db://text-mesh/settings';

const { ccclass, property } = _decorator;
 
TextMeshSettings.dilateScale = 0.8;
@ccclass('Sample')
export class Sample extends Component {
    @property(Canvas)
    canvas: Canvas;

    @property(Node)
    bg: Node;

    @property(Node)
    d3Camera: Node;

    @property(Node)
    home: Node;

    @property(Node)
    homeBtn: Node;

    @property(Node)
    opcityBtn: Node;

    @property([Node])
    menus: Node[] = [];

    @property([Node])
    pages: Node[] = [];

    @property(TextMeshLabel)
    curveLabel: TextMeshLabel;

    @property(TextMeshLabel)
    circelLabel: TextMeshLabel;

    @property(TextMeshLabel)
    animlLabel: TextMeshLabel;

    @property(TextMeshLabel)
    typeLabel: TextMeshLabel;
    
    @property(TextMeshLabel)
    clickLabel: TextMeshLabel;
    
    @property(TextMeshLabel)
    storeLabel: TextMeshLabel;

    @property(TextMeshLabel)
    websitLabel: TextMeshLabel;

    @property(TextMeshLabel)
    menu1: TextMeshLabel;

    @property(Sprite)
    sprite: Sprite;

    private _curveTimer = 0;
    private _lastClickChar: CharInfo;
    private _uiOpacity: UIOpacity;

    async start () {
        if(typeof profiler !== 'undefined' && profiler.showStats) {
            profiler.showStats();
        }else{
            setDisplayStats(true);
        }

        await Utils.until(()=>!!this.menu1.font?.fontData);

        let sp = new SpriteFrame();
        sp.texture = this.menu1.font.fontData.texture;
        this.sprite.spriteFrame = sp;

        this.homeBtn.active = false;

        this.menus.forEach((menu, index) => {
            // @ts-ignore
            menu.__index = index;
            menu.on(Node.EventType.TOUCH_END, (evt: Event) => {                
                this.homeBtn.active = true;
                this.home.active = false;               

                this.bg.active = evt.target.__index != this.pages.length - 1;
                this.d3Camera.active = !this.bg.active;

                this.pages.forEach((page, i) => {
                    page.active = i === index;
                });
            });
        });

        this.homeBtn.on(Node.EventType.TOUCH_END, () => {
            this.homeBtn.active = false;
            this.home.active = true;
            this.bg.active = true;

            this.pages.forEach((page) => {
                page.active = false;
            });
        });

        this.opcityBtn.on(Node.EventType.TOUCH_END, () => {
            this._uiOpacity = this._uiOpacity || this.canvas.getComponent(UIOpacity);
            this._uiOpacity.opacity = this._uiOpacity.opacity === 255 ? 0 : 255;
        });

        this.clickLabel.node.on(TextMeshLabel.CHAR_CLICK_EVENT, (evt: EventClickChar, touchEvt: TouchEvent)=>{
            if(this._lastClickChar) {
                this.clickLabel.setCharTransform(this._lastClickChar, 0, 0, 0, 1);
                this.clickLabel.setCharColor(this._lastClickChar);
                this._lastClickChar = null;
            }

            if(evt.charInfo) {                
                this.clickLabel.setCharTransform(evt.charInfo, 0, 0, 0, 1.5);
                this.clickLabel.setCharColor(evt.charInfo, [Color.RED, Color.GREEN, Color.BLUE, Color.YELLOW]);
                this._lastClickChar = evt.charInfo;
            }
        }, this);

        this.websitLabel.node.on(TextMeshLabel.CHAR_CLICK_EVENT, (evt: EventClickChar, touchEvt: TouchEvent)=>{
            if(evt.charInfo && evt.charInfo.click) {
                window.open(evt.charInfo.click.value, "_blank");
            }
        }, this);

        this.storeLabel.node.on(TextMeshLabel.CHAR_CLICK_EVENT, (evt: EventClickChar, touchEvt: TouchEvent)=>{
            if(evt.charInfo && evt.charInfo.click) {
                window.open(evt.charInfo.click.value, "_blank");
            }
        }, this);
    }

    private _curveLabel(label: TextMeshLabel, time: number) {
        if(!label.node.activeInHierarchy) {
            return;
        }

        let cnt = label.charInfos.length;
        let diff = Math.PI / cnt;
        for(let i=0;i<cnt;i++) {
            let charInfo = label.charInfos[i];

            label.setCharTransform(charInfo, 0, Math.sin((diff * i + time) % Math.PI) * 100 -  50, 0, 1);
        }
    }

    private _circleLabel(label: TextMeshLabel, time: number) {
        if(!label.node.activeInHierarchy) {
            return;
        }

        let cnt = label.charInfos.length;
        let diff = Math.PI * 2 / cnt;
        let tr = label.uiTransform;
        let w2 = tr.width / 2;
        let h2 = tr.height / 2;
        for(let i=0;i<cnt;i++) {
            let charInfo = label.charInfos[i];

            let t = -(diff * i + time);
            let r = 100;
            let angle = t - Math.PI / 2;
            label.setCharTransform(charInfo, Math.cos(t) * r - charInfo.x + w2, Math.sin(t) * r - charInfo.y + h2, angle, 1);
        }
    }

    private _animLabel(label: TextMeshLabel, time: number) {
        if(!label.node.activeInHierarchy) {
            return;
        }

        let cnt = label.charInfos.length;
        let diff = Math.PI / cnt;
        for(let i=0;i<cnt;i++) {
            let charInfo = label.charInfos[i];

            let t = math.clamp((diff * i - time) % Math.PI, -Math.PI * 0.5, Math.PI * 0.5) + Math.PI * 0.25;
            label.setCharTransform(charInfo, 0, Math.cos(t) * 100, 0, Math.cos(t) * 0.2 + 1);
        }
    }

    private _typeLabel(label: TextMeshLabel, time: number) {
        if(!label.node.activeInHierarchy) {
            return;
        }

        let cnt = label.charInfos.length;

        let idx = Math.floor(this._curveTimer * 5 % (cnt+1));
        label.charVisibleRatio = idx / cnt;
        for(let i=0;i<cnt;i++) {
            let charInfo = label.charInfos[i];

            label.setCharTransform(charInfo, 0, 0, 0, idx-1 == i ? 2 : 1);
            label.setCharColor(charInfo, idx-1 == i ? new Color(0, 100, 255, 255) : label.color);
        }
    }

    update (dt: number) {
        this._curveTimer += dt;
        this._curveLabel(this.curveLabel, this._curveTimer);

        this._circleLabel(this.circelLabel, this._curveTimer);

        this._animLabel(this.animlLabel, this._curveTimer);

        this._typeLabel(this.typeLabel, this._curveTimer);
    }
}
