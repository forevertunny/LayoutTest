import { _decorator, Component, Node, assetManager, director } from 'cc';
import { ResManager } from 'db://text-mesh/index';
import { Sample } from './Sample';
const { ccclass, property } = _decorator;

@ccclass('Loader')
export class Loader extends Component {
    async start() {
        await ResManager.loadAB("pkg");
        
        let ab = assetManager.getBundle("pkg");
        ab.preloadScene("sample", null, null, () => {              
            director.loadScene("sample");  
        });
    }

    update(deltaTime: number) {
        
    }
}

